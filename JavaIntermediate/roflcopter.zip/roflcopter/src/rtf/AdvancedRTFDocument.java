package rtf;

public class AdvancedRTFDocument {

}
